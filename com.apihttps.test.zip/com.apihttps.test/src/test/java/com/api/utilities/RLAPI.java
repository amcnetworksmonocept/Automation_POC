package com.api.utilities;



import java.util.ArrayList;

import com.reusable.test.ApiExecutionTypes;

public class RLAPI  {
	
	
	// ======Created Object For APIExecutionTypes Class=======
	ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
	
	
	// =====Created Method for RLAAPI Type Using Re-Usable Method From APIExecutionTypes Class=====
	
	public ArrayList<String> callingRlapiType(String JsonType, String Param) throws Exception{
		
		return apiExecutionTypes.getValue(JsonType, Param);
		
		
	}

	
}
