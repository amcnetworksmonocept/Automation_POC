package com.api.utilities;

import java.util.ArrayList;

import com.reusable.test.ApiExecutionTypes;

public class MPAPI {
	

	// =======Created Object For APIExecutionTypes Class=======
	ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
	
	
	// ======Created Method for WOAPI Type Using Re-Usable Method From APIExecutionTypes Class======
	
	public ArrayList<String> callingMPapiType(String JsonType, String Param) throws Exception{
		
		return apiExecutionTypes.getValue(JsonType, Param);
		
		
	}
	
	
	
}



