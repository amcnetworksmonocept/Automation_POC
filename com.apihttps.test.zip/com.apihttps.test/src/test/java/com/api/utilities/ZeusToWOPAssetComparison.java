package com.api.utilities;

import java.util.ArrayList;

import org.testng.Assert;

import com.reusable.test.ApiExecutionTypes;
import com.reusable.test.TestBase;

public class ZeusToWOPAssetComparison extends TestBase{

	
	ArrayList<String> wopvalues = new ArrayList<String>();

	// =====Object For ZeusData Utility Class====
	

	// ===Object For WOP_Asset_API Utility Class=====
	WOP_Asset_API Wop_asset_Api = new WOP_Asset_API();

	
	ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();

	TestBase TB = new TestBase();

	// =====Method For ZEUS to WOP Comparison========

	public void ZeustoWOPParamcomparison(String param) throws Exception {

		
		wopvalues=Wop_asset_Api.callingWOPapiAssetType("wop", param);
		 
		   for(int i =0; i<=zeusvalues.size()-1;i++) {
			   if(zeusvalues.get(i).toString().equals(wopvalues.get(i-i))){
				  
				   System.out.println("Values are matched : "+zeusvalues.get(i)+"----"+wopvalues.get(i-i));
				   logStep("Validating " + "TV-RATING" + " param name in " + " ZeusDatabase");
				   logStep("Param Values are----:" + zeusvalues.get(i));
				   		     break;
			   }
			    
	}

}
}
