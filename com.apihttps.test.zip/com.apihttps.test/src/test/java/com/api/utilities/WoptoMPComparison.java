package com.api.utilities;

import java.util.ArrayList;

import org.testng.Assert;

public class WoptoMPComparison {

	// Class Level Variables
	public ArrayList<String> MPValues;
	public ArrayList<String> WopValues;

	// ======Created Object For MPAPI Utility Class======
	MPAPI mpapi = new MPAPI();

	// =====Created Object For WOP_Master_API Utility Class======
	WOP_Master_API Wop_Master_Api = new WOP_Master_API();

	// ======Created Method For MP & WOP Parameters Comparison=====
	public void WOPtoMPParamcomparison(String MPParam, String wopParam) throws Exception, Exception {

		MPValues = mpapi.callingMPapiType("MP", MPParam);
		System.out.println("MPValues is : " + MPValues);

		WopValues = Wop_Master_Api.callingWOPapiType("WOP", wopParam);
		System.out.println("WopValues is : " + WopValues);

		outer:
			for (int wopValue = 0; wopValue <= WopValues.size() - 1; wopValue++) {
				for (int mpValue = 0; mpValue <= MPValues.size() - 1; mpValue++) {
					if (WopValues.get(wopValue).toString().contains(MPValues.get(mpValue).toString())) {
						/*System.out.println("Valeus are matched : " + WopValues.get(wopValue).toString() + "----"
								+ MPValues.get(mpValue).toString());*/
					
						Assert.assertEquals(WopValues.get(wopValue).toString(), MPValues.get(mpValue).toString());
						break outer;
					
					} else {
						/*if((wopValue==WopValues.size()-1)&&mpValue==MPValues.size() - 1) {
							Assert.fail("Valeus are not matched : " + WopValues.get(wopValue).toString() + "----"
									+ MPValues.get(mpValue).toString());
							
							
					}*/

					}
				}
			}
	}

}
