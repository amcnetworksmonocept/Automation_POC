package com.api.utilities;




import com.reusable.test.TestBase;

public class Zeus {
		
	TestBase TB= new TestBase();
	
	
	
	// =====Method For Calling Database, SQL Queries and Credentials are reading from the XL sheet===
	public void callingzeusData(int linenumber) throws Exception {
				
		TB.databaseCredentials(linenumber);
		TB.sqlQueries(linenumber);
		TB.TestVerifyDB();
		
		
	}

}
