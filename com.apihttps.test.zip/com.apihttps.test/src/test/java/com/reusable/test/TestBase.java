package com.reusable.test;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Set;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.advisory.DestinationSource;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.api.utilities.ZeusToWOPAssetComparison;

import ru.yandex.qatools.allure.annotations.Step;

public class TestBase {

	public XSSFWorkbook workbook;
	public XSSFSheet sheet;
	public XSSFRow row = null;
	public XSSFCell cell = null;
	public String[][] excelData = null;
	public int colCount = 0;
	public int rowCount = 0;
	public int lastRow;
	public String[][] excelData2;
	public String path = System.getProperty("user.dir");
	public String databaseURL;
	public String user;
	public String passWord;
	public int linenumber;
	public String data;
	public  String  zeus_aspectRatio;
	public  String zeus_Definition;
	public  String zeus_Segment;
	public String zeus_tvRating;
	public String Zeus_FormatDuration;
	public String Zeus_TXComments;
	public String zeus_Dialog;
	public String zeus_Fantancy;
	public  static ArrayList<String> ar = new ArrayList<String>();
	public static ArrayList<String> armeta = new ArrayList<String>();
	public static ArrayList<String> zeusvalues=new ArrayList<String>();
	

	// ============Method For Reading Excel File and data================
	public String[][] readingexcelFiles(String sheetname) throws Exception {

		try {
			String FilePath = path + "/ExcelFile/API_inputs.xlsx";
			FileInputStream finputStream = new FileInputStream(new File(FilePath));
			workbook = new XSSFWorkbook(finputStream);
			sheet = workbook.getSheet(sheetname);
			colCount = sheet.getRow(0).getPhysicalNumberOfCells();
			// System.out.println("Columns"+ colCount);
			rowCount = sheet.getPhysicalNumberOfRows();
			// System.out.println("Rows"+ rowCount);
			lastRow = sheet.getLastRowNum();
			excelData = new String[rowCount][colCount];
			for (int Nrow = 0; Nrow < rowCount; Nrow++) {
				row = sheet.getRow(Nrow);
				for (int Ncolumn = 0; Ncolumn < colCount; Ncolumn++) {
					cell = sheet.getRow(Nrow).getCell(Ncolumn);
					DataFormatter df = new DataFormatter();
					excelData[Nrow][Ncolumn] = df.formatCellValue(cell);
				}
			}
		} catch (Exception e) {
		}

		return excelData;
	}

	// ========Method For Reading Excel Sheet Based on SheetName=========
	public String readingExcel(String sheetName) {
		logStep("Started reading data from Excel");
		try {
			excelData2 = readingexcelFiles(sheetName);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sheetName;
	}

	// ==========Method For ActiveMQ=============
	public void activeMQ() {
		readingExcel("ZeusXML");
		String subject = "AMCN.ESB.ALL.ALL.ALL.XML.QUEUE";
		try {
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
					"tcp://dev-adam02.amcnetworks.com:61616/");

			ActiveMQConnection connection = (ActiveMQConnection) connectionFactory.createConnection();
			DestinationSource ds = connection.getDestinationSource();

			connection.start();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Destination destination = session.createQueue(subject);
			// MessageProducer is used for sending messages to the queue.
			MessageProducer producer = session.createProducer(destination);
			Set<ActiveMQQueue> queues = ds.getQueues();
			for (ActiveMQQueue activeMQQueue : queues) {
				try {
					System.out.println(activeMQQueue.getQueueName());
				} catch (JMSException e) {
					e.printStackTrace();
				}
			}

			TextMessage message = session.createTextMessage(excelData2[0][0].toString());
			producer.send(message);

			System.out.println("Text updated in :--" + subject + " queue");
			System.out.println("JCG printing@@ '" + message.getText() + "'");
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ===========Method For Database Credentials Reading From the Sheet=========

	public void databaseCredentials(int linenumber) {

		readingExcel("DatabaseCredentials");

		for (int i = 1; i <= lastRow; i++) {

			if (linenumber == i) {

				databaseURL = excelData2[linenumber][0];
				user = excelData2[linenumber][1];
				passWord = excelData2[linenumber][2];

			}

		}

	}

	// =======Method For Reading the SQL Queries From Queries sheet========

	public String sqlQueries(int linenumber) {

		readingExcel("Queries");

		for (int i = 1; i <= lastRow; i++) {
			if (linenumber == i) {
				data = excelData2[linenumber][0];

			}

		}
		return data;

	}

	// =========Method For Connecting to DataBase============

	public  void TestVerifyDB() throws SQLException, ClassNotFoundException, Exception {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String URL = databaseURL;
			String Username = user;
			String Password = passWord;
			System.out.println("Driver Loaded");
			con = DriverManager.getConnection(URL, Username, Password);

			if (con != null) {
				System.out.println("Connected to the Database...");
			}
			Statement stmt = con.createStatement();
			System.out.println("Connection successfull" + stmt.toString());
		}

		catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e1) {
			e1.getMessage();
		}
		// step3 create the statement object
		Statement stmt = con.createStatement();
		// step4 execute query
		ResultSet rs = stmt.executeQuery(data);
		// stmt.executeQuery(query2);
		
		
		while (rs.next()) {
			
			ResultSetMetaData metaData = rs.getMetaData();
			
			int count = metaData.getColumnCount(); //number of column
			String columnName[] = new String[count];

			for (int i = 1; i <= count; i++)
			{
			   columnName[i-1] = metaData.getColumnLabel(i);
			   armeta.add(columnName[i-1]);
			  
			   ar.add(rs.getString(i));
		
			}

			//System.out.println("Meta data is  : "+armeta);
			//System.out.println("ar data is  : "+ar);		
			
		}

		con.close();
		

	}
	
	

	// ===========Method For Allure Reports=========
	@Step("{0}")
	public void logStep(String stepName) {

	}

}
