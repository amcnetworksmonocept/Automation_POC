package com.runner.test;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.api.utilities.Zeus;
import com.api.utilities.ZeusConversionData;
import com.api.utilities.ZeusToWOPAssetComparison;
import com.reusable.test.ApiExecutionTypes;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.Title;

public class ZeustoWOPParamcomparisonTest {

	ZeusToWOPAssetComparison zeustowop = new ZeusToWOPAssetComparison();
	Zeus zueus = new Zeus();
	ZeusConversionData zcd = new ZeusConversionData();
		
	@Features("ZEUSToWOP")
	@Stories("ZEUSToWOP Test")
	@Test(priority =1)
	@Title("SegmentCount Comparison From Zeus to WOP")
	public void TxCommentsComparison() throws Exception {
		
      zeustowop.ZeustoWOPParamcomparison("TX_COMMENTS");
		
	}
		
	
	@Features("ZEUSToWOP")
	@Stories("ZEUSToWOP Test")
	@Test(priority =2)
	@Title("TVRating Comparison From Zeus to WOP")
	public void TVRating() throws Exception {
		
      zeustowop.ZeustoWOPParamcomparison("TV_RATING");
		
	}
	
			
	@BeforeTest()
	public void beforeTest() throws Exception, IOException {
		ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
		apiExecutionTypes.APIResponse("WOPAPIASSET");
		zueus.callingzeusData(1);
		zcd.getFieldValidation();
		
		
	}
	
	
	
}
