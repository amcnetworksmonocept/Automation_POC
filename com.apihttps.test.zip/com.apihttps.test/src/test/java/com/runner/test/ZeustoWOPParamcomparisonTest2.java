package com.runner.test;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.api.utilities.Zeus;
import com.api.utilities.ZeusConversionData;
import com.api.utilities.ZeusToWOPAssetComparison;
import com.reusable.test.ApiExecutionTypes;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.Title;

public class ZeustoWOPParamcomparisonTest2 {

	ZeusToWOPAssetComparison zeustowop = new ZeusToWOPAssetComparison();
	Zeus zueus = new Zeus();
	ZeusConversionData zcd = new ZeusConversionData();

	    @Features("ZEUSToWOP")
	    @Stories("ZEUSToWOP Test")
	    @Test
	    @Title("Aspect_Ratio Comparison From Zeus to WOP")
		public void aspectRatio() throws Exception {
			zeustowop.ZeustoWOPParamcomparison("ASPECT_RATIO");	
		}
	
	    @Features("ZEUSToWOP")
	    @Stories("ZEUSToWOP Test")
	    @Test
	    @Title("VideoFormat Comparison From Zeus to WOP")
		public void videoFormat() throws Exception {
			zeustowop.ZeustoWOPParamcomparison("VideoFormat");	
		}
		
		
		
	    @Features("ZEUSToWOP")
	    @Stories("ZEUSToWOP Test")
	    @Test
	    @Title("SEGMENTCOUNT Comparison From Zeus to WOP")
		public void SegmentCount() throws Exception {
			zeustowop.ZeustoWOPParamcomparison("SEGMENT_COUNT");	
		}
		
	
	@BeforeTest()
	public void beforeTest() throws Exception, IOException {
		ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
		apiExecutionTypes.APIResponse("WOPAPIASSET1");
		zueus.callingzeusData(1);
		zcd.getFieldValidation();
		zcd.zeusCoversion("wop");
	}
	
	
	
}