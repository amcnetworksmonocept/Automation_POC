package com.api.utilities;



import com.reusable.test.TestBase;

public class ZeusConversionData extends TestBase {

	public String XlSource;
	public  String Destination;
	public String temp_aspectRatio;
	public String result=null;
	public static String TV="TV-";
	String Final;
	public String Aspratio;

	TestBase TB = new TestBase();
	Zeus zeus = new Zeus();

	// ======Method For ZEUS Transformation Values======

	public String zeusCoversion(String format) throws Exception {

		if (format.equalsIgnoreCase("wop")) {
			readingExcel("Aspect_Ratio_ZtoWOP");
		} else if (format.equalsIgnoreCase("mp")) {
			readingExcel("Aspect_Ratio_ZtoMP");
		}

		temp_aspectRatio =Aspratio;
		for (int i = 1; i < lastRow; i++) {

			XlSource = excelData2[i][0];
			Destination = excelData2[i][1];

			if (temp_aspectRatio.contains(XlSource)) {
				temp_aspectRatio = Destination;
				break;

			}

		}
		zeusvalues.add(temp_aspectRatio);
		return temp_aspectRatio;
		
	}

	public void getFieldValidation() {
		readingExcel("ZuesFields");
		String concateValue = null;
		String tvRating = null;
		
		String dbValue;
		for(int row=0;row<=lastRow;row++) {
			for(int field=0;field<=armeta.size()-1;field++) {
				if(armeta.get(field).toString().equalsIgnoreCase(excelData2[row][0])) {
					dbValue = ar.get(field).toString(); 
					if(excelData2[row][0].contains("TV_RATING")){
						tvRating=dbValue;
					}else if(excelData2[row][0].contains("ASPECT_RATIO")){
						Aspratio=dbValue;
					}else  if(dbValue.equals("Y")) {
						concateValue=concateValue.concat(Character.toString(armeta.get(field).toString().charAt(0)));
						System.out.println(excelData2[row][0]+ " is : "+armeta.get(field).toString());
					}else {
						concateValue="";
					}
					System.out.println(excelData2[row][0]+" is : "+dbValue);
					zeusvalues.add(dbValue);
					break;
				}

			}
			//System.out.println("==================");
		}
		String updatedRating = "TV-"+tvRating+concateValue;
		//System.out.println(updatedRating);
		zeusvalues.add(updatedRating);
	}
	

}