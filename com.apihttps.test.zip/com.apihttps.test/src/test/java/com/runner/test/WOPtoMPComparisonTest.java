package com.runner.test;

import java.io.IOException;


import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.api.utilities.WoptoMPComparison;
import com.reusable.test.ApiExecutionTypes;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.Title;

public class WOPtoMPComparisonTest {

	WoptoMPComparison mpwop = new WoptoMPComparison();

	@Features("WOPTOMP")
	@Stories("WOPTOMP Test")
	@Test(priority = 1)
	@Title("Tilte Comparison From WOP to MP")
	public void TitleComparison() throws Exception {

		mpwop.WOPtoMPParamcomparison("Title", "Title");

	}

	@Features("WOPTOMP")
	@Stories("WOPTOMP Test")
	@Test(priority = 2)
	@Title("AMCNID Comparison From WOP to MP")
	public void AMCNIDComparison() throws Exception {

		mpwop.WOPtoMPParamcomparison("AMCN ID", "AMCN ID");

	}

	@Features("WOPTOMP")
	@Stories("WOPTOMP Test")
	@Test(priority = 3)
	@Title("ShowType Comparison From WOP to MP")
	public void AssetTypeComparison() throws Exception {
		mpwop.WOPtoMPParamcomparison("ShowType", "ShowType");

	}

	@Features("WOPTOMP")
	@Stories("WOPTOMP Test")
	@Test(priority = 4)
	@Title("Release Year Comparison  From WOP to MP")
	public void ReleaseYearComparison() throws Exception {

		mpwop.WOPtoMPParamcomparison("Release Year", "Release Year");

	}

	@Features("WOPTOMP")
	@Stories("WOPTOMP Test")
	@Test(priority = 5)
	@Title("Asset Source Comparison From WOP to MP")
	public void AssetSourceComparison() throws Exception {

		mpwop.WOPtoMPParamcomparison("Asset Source", "Asset Source");

	}

	
	@Features("WOPTOMP")
	@Stories("WOPTOMP Test")
	@Test(priority = 6)
	@Title("Asset Owner Network Comparison From WOP to MP")
	public void OwnerNetworkComparison() throws Exception {

		mpwop.WOPtoMPParamcomparison("Owner Network", "Owner Network");

	}
	
	
	@BeforeTest
	public void beforeTest() throws Exception, IOException {
		ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
		apiExecutionTypes.APIResponse("MPAPI");
		apiExecutionTypes.APIResponse("WOPAPIMASTER");
	}
	

}
