package com.runner.test;

import java.io.IOException;


import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.api.utilities.RLtoWopComparison;
import com.reusable.test.ApiExecutionTypes;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.Title;

public class RLtoWOPComparisonTest {
	
	RLtoWopComparison rlwop = new RLtoWopComparison();
	
	@Features("RLToWOP")
	@Stories("RLToWOP Test")
	@Test(priority=1)
	@Title("AMCNID Comparison From RL to WOP")
	public void AMCNIDComparison() throws Exception {
		
		rlwop.RLtoWopParamcomparison("ID", "AMCN ID");
		
	}

	@Features("RLToWOP")
	@Stories("RLToWOP Test")
    @Test(priority=2)
	@Title("Release Year Comparison From RL to WOP")
     public void ReleaseYearComparison() throws Exception {
		
		rlwop.RLtoWopParamcomparison("Release Year", "Release Year");
		
	}
    
	
	@Features("RLToWOP")
	@Stories("RLToWOP Test")
    @Test(priority=3) 
	@Title("AssetType Comparison From RL to WOP")
    public void AssetTypeComparison() throws Exception {
		
		rlwop.RLtoWopParamcomparison("AssetType", "ShowType");
		
	}


	
	@Features("RLToWOP")
	@Stories("RLToWOP Test")
    @Test(priority=4) 
	@Title("Vendor Comparison From RL to WOP")
    public void VendorComparison() throws Exception {
		
		rlwop.RLtoWopParamcomparison("Vendor", "Supplier");
		
	}
    	
    
    @BeforeTest
	public void beforeTest() throws Exception, IOException {
		ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
		apiExecutionTypes.APIResponse("RLAPI");
		apiExecutionTypes.APIResponse("WOPAPIMASTER");
	}
   
    
    
   
}
