package com.runner.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.api.utilities.SymboxAPI;
import com.reusable.test.ApiExecutionTypes;

public class SymboxAPITest {
	SymboxAPI SAPI = new SymboxAPI();
	ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();

	
	@Test(priority=1)
	public void requestBodyForMediaTest() throws ClientProtocolException, IOException {

		SAPI.requestBodyForMedia("Media_Asset.xml");
		apiExecutionTypes.APIResponse("SymboxAPI");

	}

	@Test(priority=2)
	public void requestBodyForCompTest() throws ClientProtocolException, IOException {
		SAPI.requestBodyForComp("Component_Data.xml");
		apiExecutionTypes.APIResponse("SymboxAPI");
	}

}
