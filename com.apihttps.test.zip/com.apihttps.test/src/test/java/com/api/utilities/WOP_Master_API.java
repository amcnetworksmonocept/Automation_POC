package com.api.utilities;

import java.util.ArrayList;

import com.reusable.test.ApiExecutionTypes;

public class WOP_Master_API {
	
	// =======Created Object For APIExecutionTypes Class=======
	ApiExecutionTypes apiExecutionTypes = new ApiExecutionTypes();
	
	
	// ======Created Method for WOPAPI Type Using Re-Usable Method From APIExecutionTypes Class=======
	
	public ArrayList<String> callingWOPapiType(String JsonType, String Param) throws Exception{
		
		  return apiExecutionTypes.getValue(JsonType, Param);
		
		
	}
	
	
	

	

}
