package com.api.utilities;

import java.util.ArrayList;

import org.testng.Assert;

public class RLtoWopComparison {

	// ========Class Level Variables====
	public ArrayList<String> RLValues;
	public ArrayList<String> WopValues;

	// =====Created Object For RLAPI Utility Class======
	RLAPI rlapi = new RLAPI();

	// ======Created Object For WOP_Master_API Utility Class=====
	WOP_Master_API Wop_Master_Api = new WOP_Master_API();

	// =======Created Method For RL & WOP Parameters Comparison=======
	public void RLtoWopParamcomparison(String RlParam, String wopParam) throws Exception, Exception {

	    RLValues = rlapi.callingRlapiType("RL", RlParam);
		System.out.println("RLValues is : " + RLValues);
		
		WopValues = Wop_Master_Api.callingWOPapiType("WOP", wopParam);
		System.out.println("WopValues is : " + WopValues);

		for (int wopValue = 0; wopValue <= WopValues.size() - 1; wopValue++) {
			for (int rlValue = 0; rlValue <= RLValues.size() - 1; rlValue++) {
				if (WopValues.get(wopValue).toString().contains(RLValues.get(rlValue).toString())) {
					System.out.println("Valeus are matched : " + WopValues.get(wopValue).toString() + "----"
							+ RLValues.get(rlValue).toString());
					//Assert.assertEquals(WopValues.get(wopValue).toString(), RLValues.get(rlValue).toString());
					break;
				} else {
					System.out.println("Valeus are not matched : " + WopValues.get(wopValue).toString() + "----"
							+ RLValues.get(rlValue).toString());
					break;
					//Assert.assertEquals(WopValues.get(wopValue).toString(), RLValues.get(rlValue).toString());
					

				}
			}
		}
	}

}
