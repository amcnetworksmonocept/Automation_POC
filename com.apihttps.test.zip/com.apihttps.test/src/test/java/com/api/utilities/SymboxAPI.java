package com.api.utilities;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import com.reusable.test.ApiExecutionTypes;

public class SymboxAPI extends ApiExecutionTypes{

	public void requestBodyForMedia(String xmlfile) {
		externalFileName=xmlfile;
		try {
			byte[] requestBodyForMedia = Files.readAllBytes(Paths.get(externalFileName));

			byte[] messageId = "GOR-0001".getBytes(Charset.forName("UTF-8"));
			byte[] key = "Symb0x@2".getBytes(Charset.forName("UTF-8"));

			Mac mac = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret = new SecretKeySpec(key, "HmacSHA256");
			mac.init(secret);

			byte[] input = new byte[messageId.length + requestBodyForMedia.length];
			System.arraycopy(messageId, 0, input, 0, messageId.length);
			System.arraycopy(requestBodyForMedia, 0, input, messageId.length, requestBodyForMedia.length);

			byte[] hash = mac.doFinal(input);
			byte[] result = Base64.encodeBase64(hash);
			accessToken = new String(result, Charset.forName("UTF-8"));
			System.out.println("HMAC KEY FOR MEDIA ASSET DATA: " + accessToken);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void requestBodyForComp(String xmlfile) {
		externalFileName=xmlfile;

		try {
			byte[] requestBodyForComp = Files.readAllBytes(Paths.get(externalFileName));

			byte[] messageId = "GOR-0001".getBytes(Charset.forName("UTF-8"));
			byte[] key = "Symb0x@2".getBytes(Charset.forName("UTF-8"));

			Mac mac = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret = new SecretKeySpec(key, "HmacSHA256");
			mac.init(secret);

			byte[] input = new byte[messageId.length + requestBodyForComp.length];
			System.arraycopy(messageId, 0, input, 0, messageId.length);
			System.arraycopy(requestBodyForComp, 0, input, messageId.length, requestBodyForComp.length);

			byte[] hash = mac.doFinal(input);
			byte[] result = Base64.encodeBase64(hash);
			accessToken = new String(result, Charset.forName("UTF-8"));

			System.out.println("HMAC KEY FOR COMPONENT DATA: " +accessToken );
			System.out.println(result);
			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
